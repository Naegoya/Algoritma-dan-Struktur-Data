package Tugas1;

public class node {
    String nama;
    int nomor;
    node prev, next;

    node(node prev, int nomor, String nama, node next) {
        this.prev = prev;
        this.nama = nama;
        this.nomor = nomor;
        this.next = next;
    }
}
