package Tugas2;

public class Node {

    String judulFilm,rating;;
    int idFilm; 
    int data;
    Node prev,next;
    
    Node (Node prev, int idFilm, String judulFilm, String rating, Node next) {
    this.prev = prev;
    this.idFilm = idFilm;
    this.judulFilm = judulFilm;
    this.rating = rating;
    this.next = next;
    
    }
}
